from .geolocations import (
    CitiesViewSet, CountryTimeZoneViewSet,
    CountriesViewSet, CurrencyViewSet, CallingCodeWithNameViewSet,
)
from .categories_managment import (
    CategoriesViewSet,PriceGroupViewSet,
)
from .templates import (
    TemplatesViewSet,
)
